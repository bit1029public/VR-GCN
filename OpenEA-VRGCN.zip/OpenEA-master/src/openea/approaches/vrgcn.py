import time
import os
import pickle
import random
import math

import numpy as np
import pandas as pd

import scipy
import tensorflow as tf
import scipy.sparse as sp

from scipy.sparse.linalg.eigen.arpack import eigsh
from openea.modules.utils.util import generate_out_folder

from openea.modules.bootstrapping.alignment_finder import find_alignment
from openea.modules.finding.alignment import greedy_alignment
from openea.modules.utils.util import task_divide, merge_dic
from openea.modules.finding.similarity import sim
from openea.modules.finding.evaluation import early_stop
import openea.modules.load.read as rd
from openea.models.basic_model import BasicModel

print("here")
# get a sparse tensor based on relational triples
def get_sparse_tensor_in(e, KG):
    KG_transpose = np.transpose(KG)
    receiver_indices = KG_transpose[2]
    mtr_values = np.ones_like(receiver_indices).astype('float32')
    message_indices = range(len(KG))
    mtr_indices = np.transpose(np.stack([receiver_indices, message_indices])).astype("int64")
    mtr_shape = (np.stack([e, len(KG)])).astype("int64")
    M = tf.SparseTensor(indices=mtr_indices, values=mtr_values, dense_shape=mtr_shape)
    return M

def get_sparse_tensor_out(e, KG):
    KG_transpose = np.transpose(KG)
    sender_indices = KG_transpose[0]
    mtr_values = (np.ones_like(sender_indices)).astype('float32')
    message_indices = range(len(KG))
    mtr_indices = (np.transpose(np.stack([sender_indices, message_indices]))).astype("int64")
    mtr_shape = (np.stack([e, len(KG)])).astype("int64")
    M = tf.SparseTensor(indices=mtr_indices, values=mtr_values, dense_shape=mtr_shape)
    return M

def get_degree(e, KG):
    du = [1] * e
    for tri in KG:  # 实体的度
        if tri[0] != tri[2]:
            du[tri[0]] += 1
            du[tri[2]] += 1
    return (np.array(du).reshape([-1, 1])).astype(np.float32)

def enhance_triples(kg1, kg2, ents1, ents2):
    assert len(ents1) == len(ents2)
    print("before enhanced:", len(kg1.triples), len(kg2.triples))
    enhanced_triples1, enhanced_triples2 = set(), set()
    links1 = dict(zip(ents1, ents2))
    links2 = dict(zip(ents2, ents1))
    for h1, r1, t1 in kg1.triples:
        h2 = links1.get(h1, None)
        t2 = links1.get(t1, None)
        if h2 is not None and t2 is not None and t2 not in kg2.out_related_ents_dict.get(h2, set()):
            enhanced_triples2.add((h2, r1, t2))
    for h2, r2, t2 in kg2.triples:
        h1 = links2.get(h2, None)
        t1 = links2.get(t2, None)
        if h1 is not None and t1 is not None and t1 not in kg1.out_related_ents_dict.get(h1, set()):
            enhanced_triples1.add((h1, r2, t1))
    print("after enhanced:", len(enhanced_triples1), len(enhanced_triples2))
    return enhanced_triples1, enhanced_triples2


def dropout(inputs, drop_rate, noise_shape, is_sparse):
    if not is_sparse:
        return tf.nn.dropout(inputs, drop_rate)
    return sparse_dropout(inputs, drop_rate, noise_shape)


def sparse_dropout(x, drop_rate, noise_shape):
    """
    Dropout for sparse tensors.
    """
    keep_prob = 1 - drop_rate
    random_tensor = keep_prob
    random_tensor += tf.random.uniform(noise_shape)
    dropout_mask = tf.cast(tf.floor(random_tensor), dtype=tf.bool)
    pre_out = tf.sparse.retain(x, dropout_mask)
    return pre_out * (1. / keep_prob)


def generate_neighbours(entity_embeds1, entity_list1, entity_embeds2, entity_list2, neighbors_num, threads_num=4):
    ent_frags = task_divide(np.array(entity_list1), threads_num)
    ent_frag_indexes = task_divide(np.array(range(len(entity_list1))), threads_num)
    dic = dict()
    for i in range(len(ent_frags)):
        res = find_neighbours(ent_frags[i], entity_embeds1[ent_frag_indexes[i], :], np.array(entity_list2),
                              entity_embeds2, neighbors_num)
        dic = merge_dic(dic, res)
    return dic


def find_neighbours(frags, sub_embed1, entity_list2, embed2, k):
    dic = dict()
    sim_mat = np.matmul(sub_embed1, embed2.T)
    # sim_mat = -scipy.spatial.distance.cdist(sub_embed1, embed2, metric='cityblock')
    for i in range(sim_mat.shape[0]):
        sort_index = np.argpartition(-sim_mat[i, :], k)
        neighbors_index = sort_index[0:k]
        neighbors = entity_list2[neighbors_index].tolist()
        dic[frags[i]] = neighbors
    return dic


class AKG:
    def __init__(self, triples, ori_triples=None):
        self.triples = set(triples)
        self.triple_list = list(self.triples)
        self.triples_num = len(self.triples)

        self.heads = set([triple[0] for triple in self.triple_list])
        self.props = set([triple[1] for triple in self.triple_list])
        self.tails = set([triple[2] for triple in self.triple_list])
        self.ents = self.heads | self.tails

        print("triples num", self.triples_num)

        print("head ent num", len(self.heads))
        print("total ent num", len(self.ents))

        self.prop_list = list(self.props)
        self.ent_list = list(self.ents)
        self.prop_list.sort()
        self.ent_list.sort()

        if ori_triples is None:
            self.ori_triples = None
        else:
            self.ori_triples = set(ori_triples)

        self._generate_related_ents()

    def _generate_related_ents(self):
        self.out_related_ents_dict = dict()
        self.in_related_ents_dict = dict()
        for h, r, t in self.triple_list:
            out_related_ents = self.out_related_ents_dict.get(h, set())
            out_related_ents.add(t)
            self.out_related_ents_dict[h] = out_related_ents

            in_related_ents = self.in_related_ents_dict.get(t, set())
            in_related_ents.add(h)
            self.in_related_ents_dict[t] = in_related_ents


class Ent_Conv:
    def __init__(self,  M_in, M_out, KG, du, dim,
                 dropout_rate=0.0,
                 name='ent_conv',
                 activation=tf.keras.activations.get("relu"),
                 use_bias=False):
        
        self.dim = dim
        self.M_in = M_in
        self.M_out = M_out
        self.KG = KG
        self.du = du
        self.dropout_rate = dropout_rate
        self.activation = activation
        self.use_bias = use_bias
        self.kernels = list()
        self.bias = list()
        self.name = name
        self.data_type = tf.float32
        self._get_variable()

    def _get_variable(self):
        self.batch_normalization = tf.keras.layers.BatchNormalization()
        self.kernels = tf.get_variable(self.name + '_kernel',
                                            shape=(1, self.dim),
                                            initializer=tf.ones_initializer(),
                                            regularizer=tf.contrib.layers.l2_regularizer(scale=0.01),
                                            dtype=self.data_type)
        if self.use_bias:
            self.bias = tf.get_variable(self.name + '_bias', shape=[self.dim, ],
                                        initializer=tf.zeros_initializer(),
                                        dtype=self.data_type)

    def call(self, ent_embedding, rel_embedding):
        ent_embedding = self.batch_normalization(ent_embedding)
        if self.dropout_rate > 0.0:
            ent_embedding = dropout(ent_embedding, self.dropout_rate, 0, False)
            rel_embedding = dropout(rel_embedding, self.dropout_rate, 0, False)
        
        ent_embedding = tf.multiply(ent_embedding, self.kernels)
        rel_embedding = tf.multiply(rel_embedding, self.kernels)

        head_embedding = tf.nn.embedding_lookup(ent_embedding, tf.transpose(self.KG)[0])
        relation_embedding = tf.nn.embedding_lookup(rel_embedding, tf.transpose(self.KG)[1])
        tail_embedding = tf.nn.embedding_lookup(ent_embedding, tf.transpose(self.KG)[2])
        receiver_embedding = head_embedding + relation_embedding
        sender_embedding = tail_embedding - relation_embedding
        print('adding a layer...')
        sum_in = tf.sparse_tensor_dense_matmul(self.M_in, receiver_embedding)
        sum_out = tf.sparse_tensor_dense_matmul(self.M_out, sender_embedding)
        outputs = (1.0 / self.du) * (sum_out + sum_in + ent_embedding)
        if self.activation is not None:
            return self.activation(outputs)
        return outputs

class VRGCN(BasicModel):

    def set_kgs(self, kgs):
        self.kgs = kgs
        self.kg1 = AKG(self.kgs.kg1.relation_triples_set)
        self.kg2 = AKG(self.kgs.kg2.relation_triples_set)

    def set_args(self, args):
        self.args = args
        self.out_folder = generate_out_folder(self.args.output, self.args.training_data, self.args.dataset_division,
                                              self.__class__.__name__)

    def init(self):
        self.ref_ent1 = self.kgs.test_entities1 + self.kgs.valid_entities1
        self.ref_ent2 = self.kgs.test_entities2 + self.kgs.valid_entities2
        self.sup_ent1 = self.kgs.train_entities1
        self.sup_ent2 = self.kgs.train_entities2
        self.sup_rel1 = self.kgs.sup_rel1
        self.sup_rel2 = self.kgs.sup_rel2
        self.rel_batch_size = len(self.sup_rel1)
        print(self.rel_batch_size, "rel_batch_size")
        self.ref_rel1 = self.kgs.ref_rel1
        self.ref_rel2 = self.kgs.ref_rel2
        enhanced_triples1, enhanced_triples2 = enhance_triples(self.kg1,
                                                               self.kg2,
                                                               self.sup_ent1,
                                                               self.sup_ent2)
        ori_triples = self.kg1.triple_list + self.kg2.triple_list
        self.triples = ori_triples + list(enhanced_triples1) + list(enhanced_triples2)
        self.M_in = get_sparse_tensor_in(self.kgs.entities_num, self.triples)
        self.M_out = get_sparse_tensor_out(self.kgs.entities_num, self.triples)
        self.du = get_degree(self.kgs.entities_num, self.triples)

        sup_ent1 = np.array(self.sup_ent1).reshape((len(self.sup_ent1), 1))
        sup_ent2 = np.array(self.sup_ent2).reshape((len(self.sup_ent1), 1))
        self.sup_links = np.hstack((sup_ent1, sup_ent2))

        sup_rel1 = np.array(self.sup_rel1).reshape((len(self.sup_rel1), 1))
        sup_rel2 = np.array(self.sup_rel2).reshape((len(self.sup_rel1), 1))
        self.sup_rel_links = np.hstack((sup_rel1, sup_rel2))


        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        self.session = tf.Session(config=config)
        self._get_variable()
        if self.args.rel_param > 0.0:
            self._generate_rel_graph()
        else:
            self._generate_graph()

        tf.global_variables_initializer().run(session=self.session)

    def __init__(self):
        super().__init__()
        self.ent_pos_link_batch = None
        self.ent_neg_link_batch = None
        self.rel_pos_link_batch = None
        self.rel_neg_link_batch = None
        self.sup_links_set = set()
        self.sup_rel_links_set = set()
        self.rel_output_embeds_list, self.output_embeds_list = None, None
        self.sup_links = None
        self.sup_rel_links = None
        self.model = None
        self.optimizer = None
        self.ref_ent1 = None
        self.ref_ent2 = None
        self.sup_ent1 = None
        self.sup_ent2 = None
        self.sup_rel1 = None
        self.sup_rel2 = None
        self.rel_batch_size = None
        self.session = None

    def _get_variable(self):
        self.ent_embedding = tf.get_variable('ent_embedding',
                                              shape=(self.kgs.entities_num, self.args.dim),
                                              initializer=tf.glorot_uniform_initializer(),
                                              dtype=tf.float32)
        self.rel_embedding = tf.get_variable('rel_embedding',
                                              shape=(self.kgs.relations_num, self.args.dim),
                                              initializer=tf.glorot_uniform_initializer(),
                                              dtype=tf.float32)        

    def _define_model(self):
        print('Getting VRGCN model...')
        rel_layers = list()
        ent_layers = list()
        ent_outputs = list()
        rel_outputs = list()    

        ent_layer1 = Ent_Conv(self.M_in,self.M_out, self.triples, self.du, dim=self.args.dim,
                                    dropout_rate=0.0,
                                    use_bias=True,
                                    activation=tf.keras.activations.get("relu"),                                       
                                    name='ent_conv_1')
        ent_layers.append(ent_layer1)
        ent_embed2 = ent_layer1.call(self.ent_embedding, self.rel_embedding)

        ent_layer2 = Ent_Conv(self.M_in,self.M_out, self.triples, self.du, dim=self.args.dim,
                                    dropout_rate=0.0,
                                    use_bias=True,
                                    activation=None,                                       
                                    name='ent_conv_2')
        ent_layers.append(ent_layer2)
        ent_embed3 = ent_layer2.call(ent_embed2, self.rel_embedding)

 
        ent_outputs.append(ent_embed2)
        ent_outputs.append(ent_embed3)
        rel_outputs.append(self.rel_embedding)        

        self.ent_layers = ent_layers
        self.rel_layers = rel_layers
        self.output_embeds_list = ent_outputs
        self.rel_output_embeds_list = rel_outputs

    def compute_loss(self, pos_links, neg_links, only_pos=False):
        index1 = pos_links[:, 0]
        index2 = pos_links[:, 1]
        neg_index1 = neg_links[:, 0]
        neg_index2 = neg_links[:, 1]

        embeds_list = list()
        for output_embeds in self.output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds_list.append(output_embeds)
        output_embeds = tf.concat(embeds_list, axis=1)
        output_embeds = tf.nn.l2_normalize(output_embeds, 1)

        embeds1 = tf.nn.embedding_lookup(output_embeds, tf.cast(index1, tf.int32))
        embeds2 = tf.nn.embedding_lookup(output_embeds, tf.cast(index2, tf.int32))
        pos_loss = tf.reduce_sum(tf.reduce_sum(tf.abs(embeds1 - embeds2), 1))

        embeds1 = tf.nn.embedding_lookup(output_embeds, tf.cast(neg_index1, tf.int32))
        embeds2 = tf.nn.embedding_lookup(output_embeds, tf.cast(neg_index2, tf.int32))
        neg_distance = tf.reduce_sum(tf.abs(embeds1 - embeds2), 1)
        neg_loss = tf.reduce_sum(tf.keras.activations.relu(self.args.neg_margin - neg_distance))

        return pos_loss + self.args.neg_margin_balance * neg_loss

    def compute_rel_loss(self, pos_links, neg_links, only_pos=False):
        index1 = pos_links[:, 0]
        index2 = pos_links[:, 1]
        neg_index1 = neg_links[:, 0]
        neg_index2 = neg_links[:, 1]

        embeds_list = list()
        for output_embeds in self.rel_output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds_list.append(output_embeds)
        output_embeds = tf.concat(embeds_list, axis=1)
        output_embeds = tf.nn.l2_normalize(output_embeds, 1)

        embeds1 = tf.nn.embedding_lookup(output_embeds, tf.cast(index1, tf.int32))
        embeds2 = tf.nn.embedding_lookup(output_embeds, tf.cast(index2, tf.int32))
        pos_loss = tf.reduce_sum(tf.reduce_sum(tf.abs(embeds1 - embeds2), 1))

        embeds1 = tf.nn.embedding_lookup(output_embeds, tf.cast(neg_index1, tf.int32))
        embeds2 = tf.nn.embedding_lookup(output_embeds, tf.cast(neg_index2, tf.int32))
        neg_distance = tf.reduce_sum(tf.abs(embeds1 - embeds2), 1)
        neg_loss = tf.reduce_sum(tf.keras.activations.relu(self.args.neg_rel_margin - neg_distance)) 
        return (pos_loss + self.args.neg_rel_margin_balance * neg_loss) * self.args.rel_param

    def _generate_graph(self):
        self.ent_pos_links = tf.placeholder(tf.int32, shape=[None, 2], name="pos")
        self.ent_neg_links = tf.placeholder(tf.int32, shape=[None, 2], name='neg')
        self._define_model()
        self.loss = self.compute_loss(self.ent_pos_links, self.ent_neg_links)
        self.optimizer = tf.train.AdamOptimizer(learning_rate=self.args.learning_rate).minimize(self.loss)

    def _generate_rel_graph(self):
        self.ent_pos_links = tf.placeholder(tf.int32, shape=[None, 2], name="ent_pos")
        self.ent_neg_links = tf.placeholder(tf.int32, shape=[None, 2], name='ent_neg')
        self.rel_pos_links = tf.placeholder(tf.int32, shape=[None, 2], name="rel_pos")
        self.rel_neg_links = tf.placeholder(tf.int32, shape=[None, 2], name='rel_neg')
        self._define_model()
        self.loss = self.compute_loss(self.ent_pos_links, self.ent_neg_links) + \
                    self.compute_rel_loss(self.rel_pos_links, self.rel_neg_links)
        self.optimizer = tf.train.AdamOptimizer(learning_rate=self.args.learning_rate).minimize(self.loss)


    def _eval_valid_embeddings(self):
        if len(self.kgs.valid_links) > 0:
            ent1 = self.kgs.valid_entities1
            ent2 = self.kgs.valid_entities2 + self.kgs.test_entities2
        else:
            ent1 = self.kgs.test_entities1
            ent2 = self.kgs.test_entities2
        embeds_list1, embeds_list2 = list(), list()
        output_embeds_list = self.output_embeds_list
        for output_embeds in output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds1 = tf.nn.embedding_lookup(output_embeds, ent1)
            embeds2 = tf.nn.embedding_lookup(output_embeds, ent2)
            embeds1 = tf.nn.l2_normalize(embeds1, 1)
            embeds2 = tf.nn.l2_normalize(embeds2, 1)
            embeds1 = np.array(embeds1.eval(session=self.session))
            embeds2 = np.array(embeds2.eval(session=self.session))
            embeds_list1.append(embeds1)
            embeds_list2.append(embeds2)
        embeds1 = np.concatenate(embeds_list1, axis=1)
        embeds2 = np.concatenate(embeds_list2, axis=1)
        mapping = self.mapping_mat.eval(session=self.session) if self.mapping_mat is not None else None
        return embeds1, embeds2, mapping

    def _eval_rel_valid_embeddings(self):
        rel1 = self.ref_rel1
        rel2 = self.ref_rel2
        embeds_list1, embeds_list2 = list(), list()
        output_embeds_list = self.rel_output_embeds_list
        for output_embeds in output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds1 = tf.nn.embedding_lookup(output_embeds, rel1)
            embeds2 = tf.nn.embedding_lookup(output_embeds, rel2)
            embeds1 = tf.nn.l2_normalize(embeds1, 1)
            embeds2 = tf.nn.l2_normalize(embeds2, 1)
            embeds1 = np.array(embeds1.eval(session=self.session))
            embeds2 = np.array(embeds2.eval(session=self.session))
            embeds_list1.append(embeds1)
            embeds_list2.append(embeds2)
        embeds1 = np.concatenate(embeds_list1, axis=1)
        embeds2 = np.concatenate(embeds_list2, axis=1)
        mapping = self.mapping_mat.eval(session=self.session) if self.mapping_mat is not None else None
        return embeds1, embeds2, mapping

    def _eval_test_embeddings(self):
        ent1 = self.kgs.test_entities1
        ent2 = self.kgs.test_entities2
        embeds_list1, embeds_list2 = list(), list()
        output_embeds_list = self.output_embeds_list
        for output_embeds in output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds1 = tf.nn.embedding_lookup(output_embeds, ent1)
            embeds2 = tf.nn.embedding_lookup(output_embeds, ent2)
            embeds1 = tf.nn.l2_normalize(embeds1, 1)
            embeds2 = tf.nn.l2_normalize(embeds2, 1)
            embeds1 = np.array(embeds1.eval(session=self.session))
            embeds2 = np.array(embeds2.eval(session=self.session))
            embeds_list1.append(embeds1)
            embeds_list2.append(embeds2)
        embeds1 = np.concatenate(embeds_list1, axis=1)
        embeds2 = np.concatenate(embeds_list2, axis=1)
        mapping = self.mapping_mat.eval(session=self.session) if self.mapping_mat is not None else None
        return embeds1, embeds2, mapping

    def _eval_rel_test_embeddings(self):
        rel1 = self.ref_rel1
        rel2 = self.ref_rel2
        embeds_list1, embeds_list2 = list(), list()
        output_embeds_list = self.rel_output_embeds_list
        for output_embeds in output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            embeds1 = tf.nn.embedding_lookup(output_embeds, rel1)
            embeds2 = tf.nn.embedding_lookup(output_embeds, rel2)
            embeds1 = tf.nn.l2_normalize(embeds1, 1)
            embeds2 = tf.nn.l2_normalize(embeds2, 1)
            embeds1 = np.array(embeds1.eval(session=self.session))
            embeds2 = np.array(embeds2.eval(session=self.session))
            embeds_list1.append(embeds1)
            embeds_list2.append(embeds2)
        embeds1 = np.concatenate(embeds_list1, axis=1)
        embeds2 = np.concatenate(embeds_list2, axis=1)
        mapping = self.mapping_mat.eval(session=self.session) if self.mapping_mat is not None else None
        return embeds1, embeds2, mapping

    def save(self):
        embeds_list = list()
        output_embeds_list = self.output_embeds_list
        for output_embeds in output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            output_embeds = np.array(output_embeds.eval(session=self.session))
            embeds_list.append(output_embeds)
        ent_embeds = np.concatenate(embeds_list, axis=1)
        rel_embeds_list = list()
        rel_output_embeds_list = self.rel_output_embeds_list
        for output_embeds in rel_output_embeds_list:
            output_embeds = tf.nn.l2_normalize(output_embeds, 1)
            output_embeds = np.array(output_embeds.eval(session=self.session))
            rel_embeds_list.append(output_embeds)
        rel_embeds = np.concatenate(rel_embeds_list, axis=1)        
        rd.save_embeddings(self.out_folder, self.kgs, ent_embeds, rel_embeds, None, mapping_mat=None)


    def generate_input_batch(self, batch_size, neighbors1=None, neighbors2=None):
        pos_links = self.sup_links
        neg_links = list()
        if neighbors1 is None:
            neg_ent1 = list()
            neg_ent2 = list()
            for i in range(self.args.neg_triple_num):
                neg_ent1.extend(random.sample(self.kg1.ent_list, batch_size))
                neg_ent2.extend(random.sample(self.kg2.ent_list, batch_size))
            neg_links.extend([(neg_ent1[i], neg_ent2[i]) for i in range(len(neg_ent1))])
        else:
            for i in range(batch_size):
                e1 = pos_links[i, 0]
                candidates = random.sample(neighbors1.get(e1), self.args.neg_triple_num)
                neg_links.extend([(e1, candidate) for candidate in candidates])
                e2 = pos_links[i, 1]
                candidates = random.sample(neighbors2.get(e2), self.args.neg_triple_num)
                neg_links.extend([(candidate, e2) for candidate in candidates])
        neg_links = set(neg_links) - self.sup_links_set
        neg_links = np.array(list(neg_links))
        return pos_links, neg_links


    def rel_generate_input_batch(self, batch_size, neighbors1=None, neighbors2=None):
        pos_links = self.sup_rel_links
        neg_links = list()
        if neighbors1 is None:
            neg_rel1 = list()
            neg_rel2 = list()
            for i in range(self.args.neg_rel_num):
                neg_rel1.extend(random.sample(self.kg1.prop_list, batch_size))
                neg_rel2.extend(random.sample(self.kg2.prop_list, batch_size))
            neg_links.extend([(neg_rel1[i], neg_rel2[i]) for i in range(len(neg_rel1))])
        else:
            for i in range(batch_size):
                e1 = pos_links[i, 0]
                candidates = random.sample(neighbors1.get(e1), self.args.neg_rel_num)
                neg_links.extend([(e1, candidate) for candidate in candidates])
                e2 = pos_links[i, 1]
                candidates = random.sample(neighbors2.get(e2), self.args.neg_rel_num)
                neg_links.extend([(candidate, e2) for candidate in candidates])
        neg_links = set(neg_links) - self.sup_rel_links_set
        neg_links = np.array(list(neg_links))
        return pos_links, neg_links

    def find_neighbors(self):
        if self.args.truncated_epsilon <= 0.0:
            return None, None
        start = time.time()
        output_embeds_list = self.output_embeds_list
        ents1 = np.array(self.kg1.ent_list)
        ents2 = np.array(self.kg2.ent_list)
        embeds1 = tf.nn.embedding_lookup(output_embeds_list[-1], ents1)
        embeds2 = tf.nn.embedding_lookup(output_embeds_list[-1], ents2)
        embeds1 = tf.nn.l2_normalize(embeds1, 1)
        embeds2 = tf.nn.l2_normalize(embeds2, 1)
        embeds1 = np.array(embeds1.eval(session=self.session))
        embeds2 = np.array(embeds2.eval(session=self.session))
        num = int((1 - self.args.truncated_epsilon) * len(ents1))
        print("neighbors num", num)
        neighbors1 = generate_neighbours(embeds1, ents1, embeds2, ents2, num,
                                         threads_num=self.args.test_threads_num)
        neighbors2 = generate_neighbours(embeds2, ents2, embeds1, ents1, num,
                                         threads_num=self.args.test_threads_num)
        print('finding neighbors for sampling costs time: {:.4f}s'.format(time.time() - start))
        return neighbors1, neighbors2

    def find_rel_neighbors(self):
        if self.args.truncated_epsilon <= 0.0:
            return None, None
        start = time.time()
        rel_output_embeds_list = self.rel_output_embeds_list
        rels1 = np.array(self.kg1.prop_list)
        rels2 = np.array(self.kg2.prop_list)
        embeds1 = tf.nn.embedding_lookup(rel_output_embeds_list[-1], rels1)
        embeds2 = tf.nn.embedding_lookup(rel_output_embeds_list[-1], rels2)
        embeds1 = tf.nn.l2_normalize(embeds1, 1)
        embeds2 = tf.nn.l2_normalize(embeds2, 1)
        embeds1 = np.array(embeds1.eval(session=self.session))
        embeds2 = np.array(embeds2.eval(session=self.session))
        num = int((1 - self.args.truncated_epsilon) * len(rels1))
        print("neighbors num", num)
        neighbors1 = generate_neighbours(embeds1, rels1, embeds2, rels2, num,
                                         threads_num=self.args.test_threads_num)
        neighbors2 = generate_neighbours(embeds2, rels2, embeds1, rels1, num,
                                         threads_num=self.args.test_threads_num)
        print('finding neighbors for sampling costs time: {:.4f}s'.format(time.time() - start))
        return neighbors1, neighbors2


    def run(self):
        flag1 = 0
        flag2 = 0
        neighbors1, neighbors2 = None, None
        rel_neighbors1, rel_neighbors2 = None, None
        start_begin = time.time()
        for epoch in range(1, self.args.max_epoch + 1):
            start = time.time()
            epoch_loss = 0.0
            self.ent_pos_link_batch, self.ent_neg_link_batch = self.generate_input_batch(self.args.batch_size,
                                                                                    neighbors1=neighbors1,
                                                                                    neighbors2=neighbors2)
              
            fetches = {"loss": self.loss, "optimizer": self.optimizer}
            if self.args.rel_param > 0:
                self.rel_pos_link_batch, self.rel_neg_link_batch = self.rel_generate_input_batch(self.rel_batch_size,
                                                                                     neighbors1=rel_neighbors1,
                                                                                     neighbors2=rel_neighbors2)                  
                feed_dict = {self.ent_pos_links: self.ent_pos_link_batch,
                                self.ent_neg_links: self.ent_neg_link_batch,
                                self.rel_pos_links: self.rel_pos_link_batch,
                                self.rel_neg_links: self.rel_neg_link_batch,
                                }
                results = self.session.run(fetches=fetches, feed_dict=feed_dict)
            else:
                feed_dict = {self.ent_pos_links: self.ent_pos_link_batch,
                                self.ent_neg_links: self.ent_neg_link_batch}
                results = self.session.run(fetches=fetches, feed_dict=feed_dict)
            epoch_loss = results["loss"]
            print('epoch {}, loss: {:.4f}, cost time: {:.4f}s'.format(epoch, epoch_loss, time.time() - start))
            if epoch % self.args.eval_freq == 0 and epoch >= self.args.start_valid:
                flag = self.valid(self.args.stop_metric)
                flag1, flag2, is_stop = early_stop(flag1, flag2, flag)
                if is_stop:
                    print("\n == training stop == \n")
                    break
                neighbors1, neighbors2 = self.find_neighbors()
                rel_neighbors1, rel_neighbors2 = self.find_rel_neighbors()