from openea.models.neural.conve import ConvE
from openea.models.neural.proje import ProjE
