from openea.models.semantic.distmult import DistMult
from openea.models.semantic.hole import HolE
from openea.models.semantic.simple import SimplE
from openea.models.semantic.rotate import RotatE