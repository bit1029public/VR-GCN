from openea.models.trans.transe import TransE
from openea.models.trans.transh import TransH
from openea.models.trans.transr import TransR
from openea.models.trans.transd import TransD

