# VR-GCN

Paper: "[A Vectorized Relational Graph Convolutional Network for Multi-Relational Network Alignment](https://www.ijcai.org/proceedings/2019/0574.pdf)" 

Published in the Twenty-Eighth International Joint Conference on Artificial Intelligence ([IJCAI-19](https://www.ijcai19.org/)). 


## Overview
We update our code based on the wonderful open-source library [OpenEA](https://github.com/nju-websoft/OpenEA). We add our model vrgcn.py to the OpenEA-master/run/openea/approaches folder, add vrgcn_args_15K.json to the OpenEA-master/run/args/ folder, and modify OpenEA-master/run/openea/modules/load/kgs.py to read relation anchors.


## Installation & Run a model

Installation & Run according to OpenEA-master/README.md.

e.g. python main_from_args.py ./args/vrgcn_args_15K.json fr_en_0_3 721_5fold/

If you find any problems, please feel free and email me. We will keep updating the code.

## Acknowledgements

Code is inspired by [OpenEA](https://github.com/nju-websoft/OpenEA). 

